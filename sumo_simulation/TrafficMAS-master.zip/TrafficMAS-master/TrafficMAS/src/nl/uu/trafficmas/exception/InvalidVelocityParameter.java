package nl.uu.trafficmas.exception;

public class InvalidVelocityParameter extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6095370835453123770L;

}
