package nl.uu.trafficmas.agent.actions;

public class ChangeVelocity5Action extends ChangeVelocityAction {
	public ChangeVelocity5Action(int priority) {
		super(priority);
		this.speedIncrease 	= 5;
	}
}
