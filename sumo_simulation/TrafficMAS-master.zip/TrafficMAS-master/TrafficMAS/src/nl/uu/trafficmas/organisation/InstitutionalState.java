package nl.uu.trafficmas.organisation;

public interface InstitutionalState {

}
