package nl.uu.trafficmas.roadnetwork;

public enum LaneType {
	Normal,
	Priority,
	RushHour,
	Emergency,
	Bus
}
