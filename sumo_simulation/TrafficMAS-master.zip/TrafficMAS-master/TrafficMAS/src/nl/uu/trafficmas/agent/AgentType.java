package nl.uu.trafficmas.agent;

public enum AgentType {
	Normal,
	Police,
}
