package nl.uu.trafficmas.agent.actions;

public class ChangeVelocity50Action extends ChangeVelocityAction {
	public ChangeVelocity50Action(int priority) {
		super(priority);
		this.speedIncrease = 50;
	}
}
