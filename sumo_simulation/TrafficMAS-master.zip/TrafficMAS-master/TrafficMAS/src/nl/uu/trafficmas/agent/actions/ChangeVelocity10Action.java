package nl.uu.trafficmas.agent.actions;

public class ChangeVelocity10Action extends ChangeVelocityAction {
	public ChangeVelocity10Action(int priority) {
		super(priority);
		this.speedIncrease = 10;
	}
}
