package nl.uu.trafficmas.exception;

public class InvalidDistanceParameter extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8282336764802126463L;

}
