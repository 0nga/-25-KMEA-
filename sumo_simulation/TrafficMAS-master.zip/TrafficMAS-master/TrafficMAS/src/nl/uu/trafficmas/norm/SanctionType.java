package nl.uu.trafficmas.norm;

public enum SanctionType {
	LowFine,
	HighFine,
	InfiniteFine
}
