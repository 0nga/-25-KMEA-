package nl.uu.trafficmas.agent.actions;

public class ChangeVelocity20Action extends ChangeVelocityAction {
	public ChangeVelocity20Action(int priority) {
		super(priority);
		this.speedIncrease = 20;
	}
}
