package nl.uu.trafficmas.organisation;

public interface Observer {
	public void receiveInformation(Object o);
}
