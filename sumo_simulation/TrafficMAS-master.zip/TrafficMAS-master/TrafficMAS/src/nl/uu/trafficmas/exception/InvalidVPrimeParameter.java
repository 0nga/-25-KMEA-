package nl.uu.trafficmas.exception;

public class InvalidVPrimeParameter extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 191199292150896729L;

}
