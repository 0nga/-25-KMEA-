package nl.uu.trafficmas.agent.actions;

public class ChangeVelocityMinus0Point01Action extends ChangeVelocityAction {
	public ChangeVelocityMinus0Point01Action(int priority) {
		super(priority);
		this.speedIncrease 	= -0.01;
	}
}
