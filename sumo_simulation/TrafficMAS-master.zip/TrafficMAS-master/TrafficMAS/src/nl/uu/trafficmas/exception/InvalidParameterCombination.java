package nl.uu.trafficmas.exception;

public class InvalidParameterCombination extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7012903362756011608L;

}
