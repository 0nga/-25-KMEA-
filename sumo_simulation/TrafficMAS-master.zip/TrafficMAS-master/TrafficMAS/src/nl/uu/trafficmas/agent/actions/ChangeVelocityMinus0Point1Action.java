package nl.uu.trafficmas.agent.actions;

public class ChangeVelocityMinus0Point1Action extends ChangeVelocityAction {
	public ChangeVelocityMinus0Point1Action(int priority) {
		super(priority);
		this.speedIncrease 	= -0.1;
	}
}
