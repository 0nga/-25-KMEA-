package nl.uu.trafficmas.agent;

import de.tudresden.ws.container.SumoColor;

public interface ISumoColor  {

	public abstract SumoColor getColor();
}
