package nl.uu.trafficmas.agent.actions;

public class ChangeVelocity1Action extends ChangeVelocityAction {
	public ChangeVelocity1Action(int priority) {
		super(priority);
		this.speedIncrease 	= 1;
	}
}
