package nl.uu.trafficmas.exception;

public class DistanceLargerThanRoadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5738544920776924154L;

	public DistanceLargerThanRoadException(String message) {
		super(message);
	}
	
}
