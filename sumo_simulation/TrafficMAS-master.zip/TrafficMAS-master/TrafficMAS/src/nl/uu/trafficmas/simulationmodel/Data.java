package nl.uu.trafficmas.simulationmodel;

public interface Data {

}
